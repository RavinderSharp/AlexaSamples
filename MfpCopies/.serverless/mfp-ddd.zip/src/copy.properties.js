'use strict'

var copyProperties = {
  "copies" : "1",
  "side" : "two",
  "colour" : "colour",
  "staple" : "stapled"
}
module.exports.copyProperties = copyProperties;
